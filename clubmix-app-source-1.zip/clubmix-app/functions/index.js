const {onCall,HttpsError}=require('firebase-functions/v2/https');
const {onDocumentUpdated}=require('firebase-functions/v2/firestore');
const {defineSecret}=require('firebase-functions/params');
const admin=require('firebase-admin');admin.initializeApp();const db=admin.firestore();
const clean=(v,max)=>typeof v==='string'?v.trim().slice(0,max):'';
const pattern=/^[0-9a-f]{36}$/;
const validYouTube=s=>!s||/^https:\/\/(www\.|m\.)?youtube\.com\//.test(s)||/^https:\/\/youtu\.be\//.test(s);
exports.createRequest=onCall({enforceAppCheck:true,maxInstances:20},async req=>{
 const d=req.data||{};const nickname=clean(d.nickname,40),title=clean(d.title,120),artist=clean(d.artist,100),url=clean(d.url,500),phone=clean(d.phone,11),lookupCode=clean(d.lookupCode,36),consent=d.consent===true;
 if(!nickname||!title||!pattern.test(lookupCode)||!validYouTube(url)||!(/^01[0-9]{8,9}$/.test(phone)||!phone)||(phone&&!consent))throw new HttpsError('invalid-argument','신청 정보를 확인하세요.');
 const duplicate=await db.collection('requests').where('lookupCode','==',lookupCode).limit(1).get();if(!duplicate.empty)throw new HttpsError('already-exists','조회 코드가 중복되었습니다. 다시 시도하세요.');
 const ref=await db.collection('requests').add({nickname,title,artist,url,phone,consent,lookupCode,status:'접수',createdAt:admin.firestore.FieldValue.serverTimestamp(),updatedAt:admin.firestore.FieldValue.serverTimestamp()});return {id:ref.id};
});
exports.lookupRequest=onCall({enforceAppCheck:true,maxInstances:40},async req=>{
 const lookupCode=clean(req.data?.lookupCode,36);if(!pattern.test(lookupCode))throw new HttpsError('invalid-argument','조회 코드 형식 오류');
 const snap=await db.collection('requests').where('lookupCode','==',lookupCode).limit(20).get();return {items:snap.docs.map(d=>{const x=d.data();return {id:d.id,title:x.title,artist:x.artist,nickname:x.nickname,url:x.url,status:x.status}})};
});
// Kakao Alimtalk requires an approved business channel, template, and messaging provider.
// Configure HTTPS provider endpoint and API key as Firebase secrets; no arbitrary unverified Kakao API call is assumed.
const providerUrl=defineSecret('ALIMTALK_ENDPOINT');const providerKey=defineSecret('ALIMTALK_API_KEY');
exports.notifyStatus=onDocumentUpdated({document:'requests/{id}',secrets:[providerUrl,providerKey],retry:false},async event=>{
 const before=event.data.before.data(),after=event.data.after.data();if(before.status===after.status||!after.phone||!after.consent)return;
 const endpoint=providerUrl.value();if(!endpoint.startsWith('https://')){console.warn('Alimtalk provider not configured');return}
 const resp=await fetch(endpoint,{method:'POST',headers:{'content-type':'application/json','authorization':'Bearer '+providerKey.value()},body:JSON.stringify({recipient:after.phone,templateCode:after.status==='승인'?'CLUBMIX_APPROVED':'CLUBMIX_REJECTED',variables:{song:after.title,status:after.status}})});
 if(!resp.ok)throw new Error('Provider rejected notification: '+resp.status);
});

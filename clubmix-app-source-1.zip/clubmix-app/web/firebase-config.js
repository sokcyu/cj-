// Firebase Console > Project settings > Your apps > Web app 설정으로 교체
export const firebaseConfig = {
 apiKey:'REPLACE_ME',authDomain:'REPLACE_ME.firebaseapp.com',projectId:'REPLACE_ME',appId:'REPLACE_ME'
};

export const recaptchaSiteKey='REPLACE_ME';

// Configure Firebase App Check with reCAPTCHA Enterprise in production.
